import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/api-helpers";
import Skill from "@/models/Skill";

export async function GET() {
  const result = await requireAuth();
  if ("error" in result) return result.error;
  const skills = await Skill.find({ userId: result.user._id }).sort({ order: 1 });
  return NextResponse.json({ skills: JSON.parse(JSON.stringify(skills)) });
}

export async function POST(req: NextRequest) {
  const result = await requireAuth();
  if ("error" in result) return result.error;
  const data = await req.json();
  const skill = await Skill.create({ ...data, userId: result.user._id });
  return NextResponse.json({ skill: JSON.parse(JSON.stringify(skill)) }, { status: 201 });
}
