import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/api-helpers";
import Skill from "@/models/Skill";

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const result = await requireAuth();
  if ("error" in result) return result.error;
  const { id } = await params;
  const data = await req.json();
  const skill = await Skill.findOneAndUpdate({ _id: id, userId: result.user._id }, data, { new: true });
  if (!skill) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ skill: JSON.parse(JSON.stringify(skill)) });
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const result = await requireAuth();
  if ("error" in result) return result.error;
  const { id } = await params;
  await Skill.findOneAndDelete({ _id: id, userId: result.user._id });
  return NextResponse.json({ success: true });
}
