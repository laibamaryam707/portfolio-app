import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/api-helpers";
import Profile from "@/models/Profile";

export async function GET() {
  const result = await requireAuth();
  if ("error" in result) return result.error;

  const profile = await Profile.findOne({ userId: result.user._id });
  return NextResponse.json({ profile: profile ? JSON.parse(JSON.stringify(profile)) : null });
}

export async function PUT(req: NextRequest) {
  const result = await requireAuth();
  if ("error" in result) return result.error;

  const data = await req.json();
  const profile = await Profile.findOneAndUpdate(
    { userId: result.user._id },
    { $set: data },
    { new: true, upsert: true }
  );

  return NextResponse.json({ profile: JSON.parse(JSON.stringify(profile)) });
}
