import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/api-helpers";
import Project from "@/models/Project";

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const result = await requireAuth();
  if ("error" in result) return result.error;
  const { id } = await params;
  const data = await req.json();
  if (typeof data.technologies === "string") {
    data.technologies = data.technologies.split(",").map((t: string) => t.trim()).filter(Boolean);
  }
  const project = await Project.findOneAndUpdate({ _id: id, userId: result.user._id }, data, { new: true });
  if (!project) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ project: JSON.parse(JSON.stringify(project)) });
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const result = await requireAuth();
  if ("error" in result) return result.error;
  const { id } = await params;
  await Project.findOneAndDelete({ _id: id, userId: result.user._id });
  return NextResponse.json({ success: true });
}
