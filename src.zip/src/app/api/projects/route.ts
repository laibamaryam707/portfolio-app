import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/api-helpers";
import Project from "@/models/Project";

export async function GET() {
  const result = await requireAuth();
  if ("error" in result) return result.error;
  const projects = await Project.find({ userId: result.user._id }).sort({ order: 1 });
  return NextResponse.json({ projects: JSON.parse(JSON.stringify(projects)) });
}

export async function POST(req: NextRequest) {
  const result = await requireAuth();
  if ("error" in result) return result.error;
  const data = await req.json();
  if (typeof data.technologies === "string") {
    data.technologies = data.technologies.split(",").map((t: string) => t.trim()).filter(Boolean);
  }
  const project = await Project.create({ ...data, userId: result.user._id });
  return NextResponse.json({ project: JSON.parse(JSON.stringify(project)) }, { status: 201 });
}
